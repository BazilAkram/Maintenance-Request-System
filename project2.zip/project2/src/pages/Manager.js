import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ManagerPage = () => {
    const [tenants, setTenants] = useState([]);
    const [formData, setFormData] = useState({ name: '', phone: '', email: '', check_in: '', check_out: '', apartment_number: '' });

    // Fetch tenants from the server
    useEffect(() => {
        axios.get('http://localhost:3001/api/tenants')
            .then(response => setTenants(response.data))
            .catch(error => console.error('Error fetching tenants:', error));
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // Add new tenant
    const addTenant = () => {
        axios.post('http://localhost:3001/api/tenants', formData)
            .then(response => {
                setTenants([...tenants, { ...formData, id: response.data.id }]);
                setFormData({ name: '', phone: '', email: '', check_in: '', check_out: '', apartment_number: '' });
            })
            .catch(error => console.error('Error adding tenant:', error));
    };

    // Move tenant to another apartment
    const moveTenant = (id) => {
        const newApartment = prompt("Enter new apartment number:");
        if (newApartment) {
            axios.put(`http://localhost:3001/api/tenants/${id}/move`, { apartment_number: newApartment })
                .then(() => {
                    setTenants(tenants.map(tenant => tenant.id === id ? { ...tenant, apartment_number: newApartment } : tenant));
                })
                .catch(error => console.error('Error moving tenant:', error));
        }
    };

    // Delete tenant
    const deleteTenant = (id) => {
        axios.delete(`http://localhost:3001/api/tenants/${id}`)
            .then(() => {
                setTenants(tenants.filter(tenant => tenant.id !== id));
            })
            .catch(error => console.error('Error deleting tenant:', error));
    };

    return (
        <div className="manager-page">
            <h1>Manager Page</h1>

            <h2>Add New Tenant</h2>
            <div className="tenant-form">
                <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleInputChange}/>
                <input type="text" name="phone" placeholder="Phone" value={formData.phone}
                       onChange={handleInputChange}/>
                <input type="email" name="email" placeholder="Email" value={formData.email}
                       onChange={handleInputChange}/>
                <input type="text" name="apartment_number" placeholder="Apartment Number"
                       value={formData.apartment_number} onChange={handleInputChange}/>
                <label style={{fontSize: "small"}}>Check-In Date:</label>
                <input type="date" name="check_in" placeholder="Check-In Date" value={formData.check_in}
                       onChange={handleInputChange}/>
                <label style={{fontSize: "small"}}>Check-Out Date:</label>
                <input type="date" name="check_out" placeholder="Check-Out Date" value={formData.check_out}
                       onChange={handleInputChange}/>
                <button onClick={addTenant}>Add Tenant</button>
            </div>

            <h2>Tenants</h2>
            <div className="tenant-list">
                {tenants.map((tenant) => (
                    <div key={tenant.id} className="tenant-item">
                        <p><strong>Name:</strong> {tenant.name}</p>
                        <p><strong>Phone:</strong> {tenant.phone}</p>
                        <p><strong>Email:</strong> {tenant.email}</p>
                        <p><strong>Check-In:</strong> {tenant.check_in}</p>
                        <p><strong>Check-Out:</strong> {tenant.check_out}</p>
                        <p><strong>Apartment:</strong> {tenant.apartment_number}</p>
                        <div className="tenant-actions">
                            <button onClick={() => moveTenant(tenant.id)}>Move Tenant</button>
                            <button onClick={() => deleteTenant(tenant.id)}>Delete Tenant</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ManagerPage;
