import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MaintenancePage = () => {
    const [requests, setRequests] = useState([]);
    const [status, setStatus] = useState('pending');
    const [area, setArea] = useState('');
    const [apartmentNumber, setApartmentNumber] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const fetchRequests = async () => {
        const response = await axios.get('http://localhost:3001/api/requests', {
            params: { status, area, apartment_number: apartmentNumber, start_date: startDate, end_date: endDate },
        });
        setRequests(response.data);
    };

    useEffect(() => {
        fetchRequests();
    }, [status, area, apartmentNumber, startDate, endDate, fetchRequests]);
    const updateStatus = async (id, newStatus) => {
        try {
            await axios.put(`http://localhost:3001/api/requests/${id}`, { status: newStatus });
            setRequests(requests.map((request) =>
                request.id === id ? { ...request, status: newStatus } : request
            ));
        } catch (err) {
            alert('Failed to update status');
        }
        await fetchRequests();
    };

    return (
        <div className="maintenance-page">
            <h1>Maintenance Requests</h1>
            <div id="filter-section">
                <input type="text"
                       placeholder="Enter area"
                       value={area}
                       onChange={(e) => setArea(e.target.value)}
                />
                <input type="number"
                       placeholder="Enter apartment number"
                       value={apartmentNumber}
                       onChange={(e) => setApartmentNumber(e.target.value)}
                />

                <select onChange={(e) => setStatus(e.target.value)} value={status}>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                </select>

                <input type="text" value={startDate}
                       onChange={(e) => setStartDate(e.target.value)}
                       placeholder="Start Date (YYYY-MM-DD HH:mm)"
                />
                <input type="text" value={endDate}
                       onChange={(e) => setEndDate(e.target.value)}
                       placeholder="End Date (YYYY-MM-DD HH:mm)"
                />
            </div>
            <div className="request-list">
                {requests.map((request) => (
                    <div key={request.id} className="request-item">
                        <h2>Apartment {request.apartment_number}</h2>
                        <h3>Area: {request.area}</h3>
                        <h4>{request.description}</h4>
                        <p><strong>Status:</strong> {request.status}</p>
                        {request.status === "pending" && (
                            <button className="complete-button"
                                    onClick={() =>
                                        updateStatus(request.id, "completed")}>Mark Complete</button>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MaintenancePage;
