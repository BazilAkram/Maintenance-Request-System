import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (event) => {
        event.preventDefault();
        const email = document.getElementById('username').value;
        if(email === "admin" || email === "manager"){
            navigate('/manager');
        }else if(email === "team" || email === "maintenance"){
            navigate('/maintenance');
        }else{
            try {
                const response = await fetch('http://localhost:3001/api/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email }),
                });

                const data = await response.json();
                if (response.ok) {
                    navigate('/requestForm', { state: { apartment_number: data.apartment_number } });
                } else {
                    setError(data.error);
                }
            } catch (err) {
                setError('An error occurred. Please try again.');
            }
        }
    };

    return (
        <div className="login-page">
            <h1>Login</h1>
            <form id="login-form" onSubmit={handleLogin}>
                <div className="form-group">
                    <input id="username" required/>
                </div>
                <button type="submit">Login</button>
            </form>
            {error && <p className="error">{error}</p>}
        </div>
    );
};

export default Login;
