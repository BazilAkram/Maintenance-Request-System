import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

const RequestForm = () => {
    const location = useLocation();

    const [apartmentNumber, setApartmentNumber] = useState('');
    const [area, setArea] = useState('');
    const [description, setDescription] = useState('');
    const [photo, setPhoto] = useState(null);

    // Prefill apartment number if passed from the login page
    useEffect(() => {
        if (location.state && location.state.apartment_number) {
            setApartmentNumber(location.state.apartment_number);
        }
    }, [location.state]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('apartment_number', apartmentNumber);
        formData.append('area', area);
        formData.append('description', description);
        if (photo) formData.append('photo', photo);

        try {
            const response = await axios.post('http://localhost:3001/api/requests', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            alert('Request submitted successfully!');
            window.location.reload();
        } catch (err) {
            console.error('Error during request submission:', err);
            if (err.response) {
                // If the server responded with an error
                console.error('Server error response:', err.response);
                alert(`Error: ${err.response.data.message || 'Failed to submit request'}`);
            } else if (err.request) {
                // If no response was received
                console.error('No response received:', err.request);
                alert('No response from server, please try again.');
            } else {
                // If there was an error during the request setup
                console.error('Error setting up request:', err.message);
                alert(`Request setup error: ${err.message}`);
            }
        }
    };

    return (
        <div className="RequestForm">
            <h1>Submit Maintenance Request</h1>
            <form id="maintenance-request-form" className="form-grid" onSubmit={handleSubmit}>
                <label htmlFor="apartment-number">Apartment Number:</label>
                <input type="text" id="apartment-number"
                       value={apartmentNumber}
                       readOnly={true}
                       onChange={(e) => setApartmentNumber(e.target.value)}
                       required
                />

                <label htmlFor="area">Area of Problem:</label>
                <input type="text" placeholder="Area of the Problem (e.g. Kitchen)"
                       value={area}
                       onChange={(e) => setArea(e.target.value)}
                       required
                />

                <label htmlFor="description">Brief Description of the Problem:</label>
                <textarea placeholder="Description of the Problem" rows={12}
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          required
                />

                <label htmlFor="photo">Optional Photo:</label>
                <input type="file"
                       onChange={(e) => setPhoto(e.target.files[0])}
                />

                <div className="submit-row">
                    <button type="submit">Submit Request</button>
                </div>
            </form>
        </div>
    );
}

export default RequestForm;
