import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import RequestForm from './pages/RequestForm';
import MaintenancePage from './pages/MaintenancePage';
import Manager from './pages/Manager';
import NotFoundPage from './pages/NotFoundPage';

function App() {
  return (
      <Router>
        <Routes>
            <Route path="/" exact element={<Login />} />
            <Route path="/RequestForm" exact element={<RequestForm />} />
            <Route path="/maintenance" element={<MaintenancePage />} />
            <Route path="/manager" element={<Manager />} />
            <Route path="*" element={<NotFoundPage />} /> {/* Catch-all route for 404 */}
        </Routes>
      </Router>
  );
}

export default App;
