const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const bodyParser = require('body-parser');
const cors = require('cors');


const app = express();
const port = 3001;


// Middleware
app.use(express.json());
app.use(cors());
const upload = multer({ dest: 'src/backend/uploads/' });

// SQLite database setup
const path = require('path');
const db = new sqlite3.Database(path.join(__dirname, 'maintenanceRequests.db'), (err) => {
    if (err) {
        console.error('Error opening database:', err);
    }
});

// Create table if it doesn't exist
const createTable = () => {
    db.run(`
    CREATE TABLE IF NOT EXISTS maintenance_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      apartment_number INTEGER NOT NULL,
      area TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      date_time TEXT DEFAULT current_timestamp,
      photo TEXT
    );
  `, (err) => {
        if (err) console.error('Error creating table:', err);
        else insertDummyData();
    });
};

// Insert some dummy data into the table
const insertDummyData = () => {
    const dummyRequests = [
        { apartment_number: 101, area: 'kitchen', description: 'Leaky faucet', date_time: '2024-11-01 05:15', status: 'pending', photo: null },
        { apartment_number: 102, area: 'bathroom', description: 'Clogged drain', date_time: '2024-10-01 02:25', status: 'completed', photo: null },
        { apartment_number: 103, area: 'living room', description: 'AC not cooling', date_time: '2024-11-09 08:00', status: 'pending', photo: null },
    ];

    dummyRequests.forEach(request => {
        const sql = `INSERT INTO maintenance_requests (apartment_number, area, description, date_time, status, photo) 
                 VALUES (?, ?, ?, ?, ?, ?)`;
        db.run(sql, [request.apartment_number, request.area, request.description, request.date_time, request.status, request.photo], function(err) {
            if (err) console.error('Error inserting dummy data:', err);
        });
    });
};

db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='maintenance_requests'", (err, row) => {
    if (err) {
        console.error('Error checking table existence:', err);
    } else if (!row) {
        createTable();
    }
});

// Add this after maintenance_requests table setup
const createTenantTable = () => {
    db.run(`
    CREATE TABLE IF NOT EXISTS tenants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      check_in TEXT,
      check_out TEXT,
      apartment_number TEXT NOT NULL
    );
  `, (err) => {
        if (err) console.error('Error creating Tenant table:', err);
        else insertDummyTenants();
    });
};

// Insert some dummy data into the tenants table
const insertDummyTenants = () => {
    const dummyTenants = [
        { name: "John Doe", phone: "123-456-7890", email: "john@test.com", check_in: "2024-01-01", check_out: "2024-12-31", apartment_number: "201" },
        { name: "Jane Dove", phone: "098-765-4321", email: "jane@test.com", check_in: "2024-02-15", check_out: null, apartment_number: "202" }
    ];

    const sql = `INSERT INTO tenants (name, phone, email, check_in, check_out, apartment_number) VALUES (?, ?, ?, ?, ?, ?)`;

    dummyTenants.forEach(tenant => {
        db.run(sql, [tenant.name, tenant.phone, tenant.email, tenant.check_in, tenant.check_out, tenant.apartment_number], function (err) {
            if (err) {
                console.error('Error inserting dummy tenant data:', err);
            }
        });
    });
};

// Check if the tenants table exists, and create it if it doesn’t
db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='tenants'", (err, row) => {
    if (err) {
        console.error('Error checking Tenant table existence:', err);
    } else if (!row) {
        createTenantTable();
    }
});


// Set up multer for photo upload
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './src/backend/uploads');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}_${file.originalname}`);
    }
});



// ***** Endpoints *****

// Added a GET route for '/'
app.get('/', (req, res) => {
    res.send('Server is up and running! <br>' +
        'Go to /api/requests to see request data. <br>' +
        'Go to /api/tenants to see tenants. <br> ');
});


// Tenant submits a maintenance request
app.post('/api/requests', upload.single('photo'), (req, res) => {
    const { apartment_number, area, description } = req.body;
    const photo = req.file ? req.file.filename : null;

    const sql = `INSERT INTO maintenance_requests (apartment_number, area, description, photo) 
               VALUES (?, ?, ?, ?)`;

    db.run(sql, [apartment_number, area, description, photo], function (err) {
        if (err) {
            return res.status(500).json({ error: 'Failed to submit request' });
        }
        res.status(201).json({ id: this.lastID });
    });
});


// Staff can browse maintenance requests with filters
app.get('/api/requests', (req, res) => {
    const { status, area, apartment_number, start_date, end_date } = req.query;

    // Use LIKE with wildcards for area and apartment_number if they are provided
    const statusFilter = status ? `status = ?` : '1=1';
    const areaFilter = area ? `area LIKE ?` : '1=1';
    const apartmentFilter = apartment_number ? `apartment_number LIKE ?` : '1=1';
    const dateFilter = (start_date && end_date) ? `date_time BETWEEN ? AND ?` : '1=1';

    const query = `
        SELECT * FROM maintenance_requests 
        WHERE ${statusFilter} AND ${areaFilter} AND ${apartmentFilter} AND ${dateFilter}
    `;

    const params = [
        ...(status ? [status] : []),
        ...(area ? [`%${area}%`] : []),
        ...(apartment_number ? [`%${apartment_number}%`] : []),
        ...(start_date && end_date ? [start_date, end_date] : [])
    ];

    db.all(query, params, (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to fetch requests' });
        }
        res.json(rows);
    });
});



// Staff updates the status of a request
app.put('/api/requests/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (status !== 'pending' && status !== 'completed') {
        return res.status(400).json({ error: 'Invalid status' });
    }

    const sql = 'UPDATE maintenance_requests SET status = ? WHERE id = ?';

    db.run(sql, [status, id], function (err) {
        if (err) {
            return res.status(500).json({ error: 'Failed to update request status' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Request not found' });
        }
        res.status(200).json({ message: 'Request status updated' });
    });
});


// Add a new tenant
app.post('/api/tenants', (req, res) => {
    const { name, phone, email, check_in, check_out, apartment_number } = req.body;

    const sql = `INSERT INTO tenants (name, phone, email, check_in, check_out, apartment_number)
                 VALUES (?, ?, ?, ?, ?, ?)`;
    db.run(sql, [name, phone, email, check_in, check_out, apartment_number], function (err) {
        if (err) {
            return res.status(500).json({ error: 'Failed to add tenant' });
        }
        res.status(201).json({ id: this.lastID });
    });
});

// Move a tenant to a new apartment
app.put('/api/tenants/:id/move', (req, res) => {
    const { id } = req.params;
    const { apartment_number } = req.body;

    const sql = 'UPDATE tenants SET apartment_number = ? WHERE id = ?';
    db.run(sql, [apartment_number, id], function (err) {
        if (err) {
            return res.status(500).json({ error: 'Failed to move tenant' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Tenant not found' });
        }
        res.status(200).json({ message: 'Tenant moved successfully' });
    });
});

// Delete a tenant
app.delete('/api/tenants/:id', (req, res) => {
    const { id } = req.params;

    const sql = 'DELETE FROM tenants WHERE id = ?';
    db.run(sql, [id], function (err) {
        if (err) {
            return res.status(500).json({ error: 'Failed to delete tenant' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Tenant not found' });
        }
        res.status(200).json({ message: 'Tenant deleted successfully' });
    });
});

// Endpoint to get all tenants
app.get('/api/tenants', (req, res) => {
    const sql = 'SELECT * FROM tenants';
    db.all(sql, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to retrieve tenants' });
        }
        res.status(200).json(rows);
    });
});

// Endpoint to verify tenant login by email
app.post('/api/login', (req, res) => {
    const { email } = req.body;

    const sql = 'SELECT apartment_number FROM tenants WHERE email = ?';
    db.get(sql, [email], (err, row) => {
        if (err) {
            return res.status(500).json({ error: 'Error verifying email' });
        }
        if (row) {
            return res.status(200).json({ apartment_number: row.apartment_number });
        } else {
            return res.status(404).json({ error: 'Email not found' });
        }
    });
});



app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
